import {Sentence} from "./minesweeper.js"
const s1 = new Sentence([1, 2], 1);
console.log(s1);
