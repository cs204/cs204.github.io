export const dimension = 4; 
export const nMine = 2;
