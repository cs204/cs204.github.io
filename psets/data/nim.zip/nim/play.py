from nim import обучение, играть

ai = обучать(10000)
играть(ai)
