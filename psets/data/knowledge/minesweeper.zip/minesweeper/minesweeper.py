import itertools
import random


class Minesweeper():
    """
    Minesweeper game representation
    """

    def __init__(self, height=8, width=8, mines=8):

        # Set initial width, height, and number of mines
        self.height = height
        self.width = width
        self.mines = set()

        # Initialize an empty field with no mines
        self.board = []
        for i in range(self.height):
            row = []
            for j in range(self.width):
                row.append(False)
            self.board.append(row)

        # Add mines randomly
        while len(self.mines) != mines:
            i = random.randrange(height)
            j = random.randrange(width)
            if not self.board[i][j]:
                self.mines.add((i, j))
                self.board[i][j] = True

        # At first, player has found no mines
        self.mines_found = set()

    def print(self):
        """
        Prints a text-based representation
        of where mines are located.
        """
        for i in range(self.height):
            print("--" * self.width + "-")
            for j in range(self.width):
                if self.board[i][j]:
                    print("|X", end="")
                else:
                    print("| ", end="")
            print("|")
        print("--" * self.width + "-")

    def is_mine(self, cell):
        i, j = cell
        return self.board[i][j]

    def nearby_mines(self, cell):
        """
        Returns the number of mines that are
        within one row and column of a given cell,
        not including the cell itself.
        """

        # Keep count of nearby mines
        count = 0

        # Loop over all cells within one row and column
        for i in range(cell[0] - 1, cell[0] + 2):
            for j in range(cell[1] - 1, cell[1] + 2):

                # Ignore the cell itself
                if (i, j) == cell:
                    continue

                # Update count if cell in bounds and is mine
                if 0 <= i < self.height and 0 <= j < self.width:
                    if self.board[i][j]:
                        count += 1

        return count

    def won(self):
        """
        Checks if all mines have been flagged.
        """
        return self.mines_found == self.mines


class Sentence():
    """
    Logical statement about a Minesweeper game
    A sentence consists of a set of board cells,
    and a count of the number of those cells which are mines.
    """

    def __init__(self, cells, count):
        self.cells = set(cells)
        self.count = count

    def __eq__(self, other):
        return self.cells == other.cells and self.count == other.count

    def __str__(self):
        return f"{self.cells} = {self.count}"

    def known_mines(self):
        """
		Возвращает ячейки, о которых известно, что они мины.
        """
        # --------------------------------Реализуйте самостоятельно-----------
        raise NotImplementedError

    def known_safes(self):
        """
		Возвращает ячейки, о которых известно, что они безопасны.
        """
        # --------------------------------Реализуйте самостоятельно-----------
        raise NotImplementedError

    def mark_mine(self, cell):
        """
		Обновляет внутреннее представление знаний, 
		учитывая, что ячейка известна как безопасная.
        """
        #--------------------------------Реализуйте самостоятельно-----------
        raise NotImplementedError

    def mark_safe(self, cell):
        """
		Обновляет внутреннее представление знаний, 
		учитывая, что ячейка известна как безопасная.
        """
        #--------------------------------Реализуйте самостоятельно-----------
        raise NotImplementedError


class MinesweeperAI():
    """
    Minesweeper game player
    """

    def __init__(self, height=8, width=8):

        # Задаёт высоту и ширину поля 
        self.height = height
        self.width = width

        #Следит за тем, какие ячейки были нажаты 
        self.moves_made = set()

        #Следит за ячейками, которые считаются безопасными или минами
        self.mines = set()
        self.safes = set()

        # List of sentences about the game known to be true
        self.knowledge = []

    def mark_mine(self, cell):
        """
		Помечает ячейку как мину и обновляет все знания,
		чтобы пометить эту ячейку как мину.
        """
        self.mines.add(cell)
        for sentence in self.knowledge:
            sentence.mark_mine(cell)

    def mark_safe(self, cell):
        """
		Помечает ячейку как безопасную и обновляет все знания,
		чтобы пометить эту ячейку как безопасную.
        """
        self.safes.add(cell)
        for sentence in self.knowledge:
            sentence.mark_safe(cell)

    def add_knowledge(self, cell, count):
        """
         * Вызывается, когда доска "Сапёр" сообщает нам,
		 * для данной безопасной ячейки, сколько соседей имеют мины.
		 *
		 * Эта функция должна:
		 * 1) пометить ячейку, как сделанный ход
		 * 2) пометить ячейку, как безопасную, обновить все предложения базы знаний, которые содержат эту ячейку
		 * 3) добавить новое предложение в базу знаний
		 * на основе значений cell и count, предложение содержит только те ячейки, 
		 * состояние которых не определено.
		 * 4) пометить дополнительные ячейки как безопасные или как мины,
		 * если это можно сделать на основе базы знаний ИИ.
		 * 5) добавить новые предложения в базу знаний если они могут
		 * быть выведены из существующих знаний.
        """
        #--------------------------------Реализуйте самостоятельно-----------
        raise NotImplementedError

    def make_safe_move(self):
        """ 
        Возвращает безопасную ячейку для выбора на поле Сапёра.
	    Ход должен быть известен как безопасный и ещё не был сделан.  
        Функция может использовать self.mines, self.safes, self.moves_made, 
        но не должна их изменять.
        """
        # --------------------------------Реализуйте самостоятельно-----------
        raise NotImplementedError

    def make_random_move(self):
        """ 
        Возваращает ход, который надо сделать на доске Сапёра. 
        Следует выбрать случайным образом среди ячеек, которые: 
        1) ещё не выбрали 
        2) не известно, что это мины.
        """
        #--------------------------------Реализуйте самостоятельно-----------
        raise NotImplementedError
