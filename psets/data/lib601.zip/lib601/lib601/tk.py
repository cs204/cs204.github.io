# uncompyle6 version 3.9.0
# Python bytecode version base 2.6 (62161)
# Decompiled from: Python 2.7.18 (default, Jul  1 2022, 10:30:50) 
# [GCC 11.2.0]
# Embedded file name: /home/freeman/6.01/S11/repo/codeSandbox/lib601/tk.py
# Compiled at: 2010-11-24 19:11:17
import Tkinter
if not globals().has_key('__tk_inited'):
    __tk_inited = False

def init():
    global __tk_inited
    if not __tk_inited:
        w = Tkinter.Tk()
        w.withdraw()


def setInited():
    global __tk_inited
    __tk_inited = True