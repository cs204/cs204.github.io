initialRobotLoc(1.45, 1.0)
dimensions(3.0, 3.0)


