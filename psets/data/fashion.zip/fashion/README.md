# fashion
cd fashion 
sudo apt install graphviz
python -m venv .venv
soruce .venv/bin/activat
pip install -r requirements
