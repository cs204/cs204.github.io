import lib601.sm as sm
import lib601.gfx as gfx
import lib601.util as util
from soar.io import io
import math

class XYDriver(sm.SM):
    forwardGain = 2.0
    rotationGain = 2.0
    angleEps = 0.05
    distEps = 0.02
    startState = False

    def getNextValues(self, state, inp):
        (goalPoint, sensors) = inp
        robotPose = sensors.odometry
        robotPoint = robotPose.point()
        robotTheta = robotPose.theta

        if goalPoint == None:
            return (True, io.Action())

        headingTheta = robotPoint.angleTo(goalPoint)
        if util.nearAngle(robotTheta, headingTheta, self.angleEps):
            # Направление верное, двигаемся вперёд
            r = robotPoint.distance(goalPoint)
            if  r < self.distEps:
                # Мы прибыли 
                return (True, io.Action())
            else:
                return (False, io.Action(fvel = r * self.forwardGain))
        else:
            # Поворачиваем в сторону цели
            headingError = util.fixAnglePlusMinusPi(\
                    headingTheta - robotTheta)
            return (False, io.Action(rvel = headingError * self.rotationGain))

    def done(self, state):
        return state

class SpyroGyra(sm.SM):
    distEps = 0.02
    def __init__(self, incr):
        self.incr = incr
        self.startState = ('south', 0, None)

    def getNextValues(self, state, inp):
        (direction, length, subGoal) = state
        robotPose = inp.odometry
        robotPoint = robotPose.point()
        if subGoal == None:
            subGoal = robotPoint
        if robotPoint.isNear(subGoal, self.distEps):
            # Пора изменить состояние
            length = length + self.incr
            if direction == 'east':
                direction = 'north'
                subGoal.y += length
            elif direction == 'north':
                direction = 'west'
                subGoal.x -= length
            elif direction == 'west':
                direction = 'south'
                subGoal.y -= length
            else:   # south
                direction = 'east'
                subGoal.x += length
            print('new:', direction, length, subGoal)
        return ((direction, length, subGoal), (subGoal, inp))

def spiroFlow(incr):
    return sm.Cascade(SpyroGyra(incr), XYDriver())

def setup():
	robot.behavior = spiroFlow(0.15) 
	robot.behavior.start(verbose = True)
	robot.gfx = gfx.RobotGraphics(drawSlimeTrail = True)

def step(): 
    robot.behavior.step(io.SensorInput()).execute() 
    io.done(robot.behavior.isDone())
