import lib601.sm as sm
import lib601.util as util
from soar.io import io
import math

class ForwardTSM(sm.SM):
    forwardGain = 1.0
    distTargetEpsilon = 0.01
    startState = 'start'

    def __init__(self, delta):
        self.deltaDesired = delta

    def getNextValues(self, state, inp):
        currentPos = inp.odometry.point()
        if state == 'start':
            print("Starting forward", self.deltaDesired)
            startPos = currentPos
        else:
            (startPos, lastPos) = state
        newState = (startPos, currentPos)
        error = self.deltaDesired - startPos.distance(currentPos)
        action = io.Action(fvel = self.forwardGain * error)
        return (newState, action)

    def done(self, state):
        if state == 'start':
            return False
        else:
            (startPos, lastPos) = state
            return util.within(startPos.distance(lastPos),
                    self.deltaDesired,
                    self.distTargetEpsilon)

def setup():
	robot.behavior = ForwardTSM(2.0)
	robot.behavior.start(verbose = True)


def step(): 
    robot.behavior.step(io.SensorInput()).execute() 
    io.done(robot.behavior.isDone())

