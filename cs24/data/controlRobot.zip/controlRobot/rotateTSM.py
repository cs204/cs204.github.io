import lib601.sm as sm
import lib601.util as util
from soar.io import io
import math

class RotateTSM(sm.SM):
    rotationalGain = 3.0
    angleEpsilon = 0.01
    startState = 'start'

    def __init__(self, headingDelta):
        self.headingDelta = headingDelta

    def getNextValues(self, state, inp):
        currentTheta = inp.odometry.theta
        if state == 'start':
            thetaDesired = \
                    util.fixAnglePlusMinusPi(currentTheta + self.headingDelta)
        else:
            (thetaDesired, thetaLast) = state
        newState = (thetaDesired, currentTheta)
        action = io.Action(rvel = self.rotationalGain *\
                util.fixAnglePlusMinusPi(thetaDesired - currentTheta))
        return (newState, action)

    def done(self, state):
        if state == 'start':
            return False
        else:
            (thetaDesired, thetaLast) = state
            return util.nearAngle(thetaDesired, thetaLast, self.angleEpsilon)


def setup():
	robot.behavior = RotateTSM(math.pi / 2)
	robot.behavior.start(verbose = True)

def step(): 
    robot.behavior.step(io.SensorInput()).execute() 
    io.done(robot.behavior.isDone())
