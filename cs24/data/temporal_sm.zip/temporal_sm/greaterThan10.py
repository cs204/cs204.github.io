import sm

class ConsumeFiveValues(sm.SM):
    def __init__(self, name = None):
        self.name = name

    startState = (0, 0)

    def getNextValues(self, state, inp):
        (count, total) = state
        if count == 4:
            return ((count + 1, total + inp), total + inp)
        else:
            return ((count + 1, total + inp), None)

    def done(self, state):
        (count, total) = state
        return count == 5


def greaterThan10(x):
    return x > 10

m = sm.RepeatUntil(greaterThan10, ConsumeFiveValues())
print(m.transduce(range(20), verbose=True))

m = sm.Until(greaterThan10, ConsumeFiveValues())
print(m.transduce(range(20), verbose = True))

m = sm.Until(lambda x: x == 2, ConsumeFiveValues())
print(m.transduce(range(20)))

m = sm.Until(greaterThan10, sm.Repeat(ConsumeFiveValues()))
print(m.transduce(range(20)))
