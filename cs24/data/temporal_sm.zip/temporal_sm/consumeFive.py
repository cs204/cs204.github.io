import sm

class ConsumeFiveValues(sm.SM):
    def __init__(self, name = None):
        self.name = name

    startState = (0, 0)

    def getNextValues(self, state, inp):
        (count, total) = state
        if count == 4:
            return ((count + 1, total + inp), total + inp)
        else:
            return ((count + 1, total + inp), None)

    def done(self, state):
        (count, total) = state
        return count == 5


c5 = ConsumeFiveValues()
print(c5.transduce([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], verbose = True))

print(sm.Repeat(ConsumeFiveValues(), 3).transduce(range(100)))
