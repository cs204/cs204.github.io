import sm

class CharTSM(sm.SM):
    startState = False
    def __init__(self, c, name = None):
        self.c = c
        self.name = name

    def getNextValues(self, state, inp):
        return (True, self.c)

    def done(self, state):
        return state



#a = CharTSM('a')
#b = CharTSM('b')

#a4 = sm.Repeat(a, 4)
#print(a4.run(verbose=True, printInput=False))

#m = sm.Sequence([b, a])
#print(m.run(verbose=True))

def makeTextSequenceTSM(str):
    return sm.Sequence([CharTSM(c) for c in str])

#m = makeTextSequenceTSM("Hello World")
#print(m.run(20, verbose = True, printInput = False))

m = sm.Repeat(makeTextSequenceTSM('abc'), 3)
print(m.run(verbose=True))

