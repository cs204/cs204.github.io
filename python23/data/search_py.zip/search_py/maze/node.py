class Node: 
    def __init__(self, action, state, parent): 
        self.action = action 
        self.state = state 
        self.parent = parent 

    def path(self): 
        if self.parent == None: 
            return [{"action": self.action, "state": self.state}] 
        else: 
            h1 = self.parent.path() 
            h2 = {"action": self.action, "state": self.state} 
            h1.append(h2) 
            return h1

    def strPath(self):
        path = self.path()
        pPath = ""
        for elem in path:
            if elem["action"] == None: 
                pPath += str(elem["state"])
            else:
                pPath += "-"
                pPath += str(elem["action"])
                pPath += "->"
                pPath += str(elem["state"])
        return pPath



if __name__ == "__main__":
    n1 = Node(None, "a", None)
    n2 = Node(1, "b", n1)
    print(n1.strPath())
    print(n2.strPath())
