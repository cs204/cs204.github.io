from maze.node import Node
from maze.frontier import Frontier
from maze.explored import Explored

def search(initialState, goalTest, actions, results, typeFrontier="stack", printPath=False):
    frontier = Frontier(typeFrontier)
    explored = Explored()
    initialNode = Node(None, initialState, None)
    numTest = 0
    frontier.add(initialNode)

    while True: 
        if frontier.isEmpty():
            raise Exception("No solution")
        parent = frontier.get()
        numTest += 1
        parentS = parent.state 
        explored.add(parentS)
        if goalTest(parentS): 
            if printPath: 
                print("Soluten:", parent.strPath() ) 
                print("num =", numTest) 
            return {"path": parent.path(), "num": numTest}

        if printPath: 
            print(parent.strPath())

        for action in actions(parentS):
            newS = results(parentS, action)
            newN = Node(action, newS, parent) 
            if not explored.hasState(newS):
                frontier.add(newN)

