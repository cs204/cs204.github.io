from maze.search import search

class Maze:
    def __init__(self, filename):
        with open(filename, "r") as file: 
            contents = file.read()

        # Validate start and goal
        if contents.count("A") != 1:
            raise Exception("maze must have exactly one start point")
        if contents.count("B") != 1:
            raise Exception("maze must have exactly one goal")

        # Determine width and height
        contents = contents.splitlines()
        self.height = len(contents)
        self.width = max( len(line) for line in contents)

        self.walls = []
        for i in range(self.height):
            row = []
            for j in range(self.width):
                try: 
                    if contents[i][j] == "A": 
                        self.start = (i, j) 
                        row.append(False) 
                    elif contents[i][j] == "B": 
                        self.goal = (i, j) 
                        row.append(False) 
                    elif contents[i][j] == " ":
                        row.append(False)
                    else:
                        row.append(True)
                except IndeError:
                    row.append(False) 
            self.walls.append(row)
        self.solution = None 

    def neighbors(self, state): 
        row, col = state 
        candidates = [("up", (row - 1, col)), 
                ("down", (row + 1, col)), 
                ("right", (row, col + 1)), 
                ("left", (row, col - 1))] 
        result = dict() 
        for action, (r, c) in candidates: 
            if 0 <= r < self.height and 0 <= c < self.width and not self.walls[r][c]: 
                result[action] = (r, c) 
        return result 

    def actions(self, state): 
        res = self.neighbors(state) 
        return list(res) 

    def results(self, state, action): 
        res = self.neighbors(state) 
        return res[action] 

    def goalTest(self, state): 
        return state == self.goal

    def solve(self, frontier = "queue"):
        print("Ok") 
        self.solution =  search(self.start, self.goalTest,  self.actions, self.results, frontier, False)

    def print(self):
        if self.solution is not None: 
            solution = self.solution["path"]
            res = [elem["state"] for elem in solution]
        print()
        for i, row in enumerate(self.walls):
            for j, col in enumerate(row):
                if col:
                    print("#", end="")
                elif (i, j) == self.start:
                    print("A", end="")
                elif (i, j) == self.goal:
                    print("B", end="")
                elif solution is not None and (i, j) in res:
                    print("*", end="")
                else:
                    print(" ", end="")
            print()
        print("num =", self.solution["num"])



if __name__ == "__main__":
    maze = Maze("maze2.txt") 

        

            
            






