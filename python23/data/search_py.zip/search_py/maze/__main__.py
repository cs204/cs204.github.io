from maze.maze import Maze
import sys

def main():
    if len(sys.argv) != 2:
        sys.exit("main.py maze1.txt")

    maze = Maze(sys.argv[1])
    #maze.solve(frontier="stack")
    maze.solve(frontier="queue")
    maze.print()


if __name__=="__main__":
    main()
