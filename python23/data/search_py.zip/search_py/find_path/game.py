def goalTest(s):
    return s == "e"

stateSpace = {'a':['b'], 'b': ['c', 'd'], 'c':['e'], 'd': ['f'], 'e':[], 'f':[]}

def actions(s):
    n = len(stateSpace[s])
    res = []
    for i in range(n):
        res.append(i)
    return res

def results(s, a):
    return stateSpace[s][a]
    

