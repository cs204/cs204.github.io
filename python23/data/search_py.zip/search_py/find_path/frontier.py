class Frontier:
    def __init__(self, t = "stack"):
        if not t in ["stack", "queue"]:
            raise ValueErorr("must be stack or queue")
        self._items = []
        self._t = t

    def add(self, node):
        self._items.append(node)

    def get(self): 
        if self._t == "stack": 
            return self._items.pop() 
        if self._t == "queue":
            return self._items.pop(0)

    def isEmpty(self): 
        return len(self._items) == 0

