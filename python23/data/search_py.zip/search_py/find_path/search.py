from node import Node
from frontier import Frontier
from explored import Explored

def search(initialState, goalTest, actions, results, typeFrontier="stack", printPath=False):
    frontier = Frontier(typeFrontier)
    explored = Explored()
    initialNode = Node(None, initialState, None)
    numTest = 0
    frontier.add(initialNode)

    while True: 
        if frontier.isEmpty():
            raise Exception("No solution")
        parent = frontier.get()
        numTest += 1
        parentS = parent.state 
        if goalTest(parentS): 
            if printPath: 
                print("Soluten:", parent.strPath() ) 
                print("num =", numTest) 
            return parent.path()

        if printPath: 
            print(parent.strPath())
        explored.add(parentS)

        for action in actions(parentS):
            newS = results(parentS, action)
            newN = Node(action, newS, parent) 
            if not explored.hasState(newS):
                frontier.add(newN)








	
