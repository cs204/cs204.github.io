from find_path.search import search
from find_path.game import goalTest, stateSpace, results, actions

search('a', goalTest, actions, results, "queue", True)
#search('a', goalTest, actions, results, "stack", True)



