from search import search
from game import goalTest, stateSpace, results, actions

search('a', goalTest, actions, results, "queue", True)
#search('a', goalTest, actions, results, "stack", True)



