class Explored:
    def __init__(self):
        self._items = set()

    def add(self, elem):
        self._items.add(str(elem))

    def hasState(self, s):
        return str(s) in self._items
