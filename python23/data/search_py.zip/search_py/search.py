from node import Node
from frontier import Frontier
from explored import Explored

def search(initialState, goalTest, actions, results, typeFrontier="stack", printPath=False):
    frontier = Frontier(typeFrontier)
    explored = Explored()
    initialNode = Node(None, initialState, None)
    numTest = 0
    frontier.add(initialNode)

    while True: 
        if frontier.isEmpty():
            raise Exception("No solution")
        parent = frontier.get()
        numTest += 1
        parentS = parent.state 
        if goalTest(parentS): 
            if printPath: 
                print("Soluten:", parent.strPath() ) 
                print("num =", numTest) 
            return parent.path()

        if printPath: 
            print(parent.strPath())
        explored.add(parentS)

        for action in actions(parentS):
            newS = results(parentS, action)
            newN = Node(action, newS, parent) 
            if not explored.hasState(newS):
                frontier.add(newN)

#----------node.py

class Node: 
    def __init__(self, action, state, parent): 
        self.action = action 
        self.state = state 
        self.parent = parent 

    def path(self): 
        if self.parent == None: 
            return [{"action": self.action, "state": self.state}] 
        else: 
            h1 = self.parent.path() 
            h2 = {"action": self.action, "state": self.state} 
            h1.append(h2) 
            return h1

    def strPath(self):
        path = self.path()
        pPath = ""
        for elem in path:
            if elem["action"] == None: 
                pPath += elem["state"]
            else:
                pPath += "-"
                pPath += str(elem["action"])
                pPath += "->"
                pPath += str(elem["state"])
        return pPath



if __name__ == "__main__":
    n1 = Node(None, "a", None)
    n2 = Node(1, "b", n1)
    print(n1.strPath())
    print(n2.strPath())

#=====frontier.py

class Frontier:
    def __init__(self, t = "stack"):
        if not t in ["stack", "queue"]:
            raise ValueErorr("must be stack or queue")
        self._items = []
        self._t = t

    def add(self, node):
        self._items.append(node)

    def get(self): 
        if self._t == "stack": 
            return self._items.pop() 
        if self._t == "queue":
            return self._items.pop(0)

    def isEmpty(self): 
        return len(self._items) == 0


#-----------------explored.py

class Explored:
    def __init__(self):
        self._items = set()

    def add(self, elem):
        self._items.add(str(elem))

    def hasState(self, s):
        return s in self._items
#-----------------

def goalTest(s):
    return s == "e"

stateSpace = {'a':['b'], 'b': ['c', 'd'], 'c':['e'], 'd': ['f'], 'e':[], 'f':[]}

def actions(s):
    n = len(stateSpace[s])
    res = []
    for i in range(n):
        res.append(i)
    return res

def results(s, a):
    return stateSpace[s][a]
    
#----------------------

from search import search
from game import goalTest, stateSpace, results, actions

search('a', goalTest, actions, results, "queue", True)
#search('a', goalTest, actions, results, "stack", True)





	
