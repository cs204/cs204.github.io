import csv
name = input("Как ваше имя? ")
home = input("Вы откуда? ")
with open("students4.csv", "a") as file:
    writer = csv.DictWriter(file, fieldnames=["name", "home"])
    writer.writerow({"name": name, "home": home})
