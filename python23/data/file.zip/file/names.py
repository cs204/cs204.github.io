name = input("What's your name? ")
file = open("names.txt", "w")
file.write(f"{name}\n")
file.close()

