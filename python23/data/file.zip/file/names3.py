with open("names.txt", "r") as file:
        lines = file.readlines()

print(type(lines))
print(lines)
for line in lines:
    print("hello,", line)
