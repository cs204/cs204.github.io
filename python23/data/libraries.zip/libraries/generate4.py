import random
cards=["jack", "quen", "king"]
random.shuffle(cards)
for card in cards:
    print(card)
