import sys
if len(sys.argv) < 2:
    sys.exit("Too few arguvents")

for arg in sys.argv:
    print("hello, my name is", arg)
