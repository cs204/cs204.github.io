import requests
r = requests.get('https://api.github.com/user', auth=('vadimgb11', 'successe67'))
print(r.status_code)
print(r.json())

