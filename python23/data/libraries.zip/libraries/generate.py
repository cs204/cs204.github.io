import random
coin = random.choice(["heads", "tails"])
print(coin)
