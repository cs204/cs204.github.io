def hello(name):
    print(f"hello, {name}")

def goodbye(name):
    print(f"goodbye, {name}")
