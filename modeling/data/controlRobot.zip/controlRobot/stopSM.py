import lib601.sm as sm
from soar.io import io

class StopSM(sm.SM):
	def getNextValues(self, state, inp):
		return (None, io.Action())


def setup():
	robot.behavior = StopSM()
	robot.behavior.start()

def step():
	robot.behavior.step(io.SensorInpuit(), verbose = False).exectue()

