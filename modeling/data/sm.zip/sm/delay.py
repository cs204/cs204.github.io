import sm_my
class Delay(sm_my.SM):
    def __init__(self, initVal):
        self.startState = initVal

    def getNextValues(self, state, inp):
        return (inp, state)

d = Delay(100)
print(d.transduce([2, 3, 5, 10], verbose=True))
