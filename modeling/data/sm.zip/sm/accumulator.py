import sm
class Accumulator(sm.SM):
    def __init__(self, iv, name = None):
        self.startState = iv
        self.name = name

    def getNextValues(self, state, inp):
        return (state + inp, state + inp)


ma = Accumulator(0)
print(ma.transduce([1, 2, 3], verbose=True))
