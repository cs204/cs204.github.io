"""
Игрок в крестики - нолики
"""
import copy
import math

X = "X"
O = "O"
EMPTY = None


def начальное_состояние():
    """
    Возвращает начальное состояние на поле
    """
    return [[EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY]]


def игрок(поле):
    """
    Находит игрока, который делает следующий ход на поле.
    """
    raise NotImplementedError


def действия(поле):
    """
    Находит все возможные действия (i, j) допустимые на поле.
    """
    raise NotImplementedError


def результат(поле, действие):
    """
    Возвращает состояние поля, которое получается после хода (i,j) из поля.
    """
    raise NotImplementedError

def победитель(поле):
    """
    Вычисляет победителя игры, если он есть.
    """
    raise NotImplementedError



def конец(поле):
    """
    Возвращает True, если игра законченна и False, если нет.
    """
    raise NotImplementedError



def оценка(поле):
    """
    Возвращает 1, если выиграл X, -1 если выиграл O, 0 в противном случае.
    """
    raise NotImplementedError

def minimax(поле):
    """
    Вычисляет оптимальное действие для игрока на поле.
    """
    raise NotImplementedError
