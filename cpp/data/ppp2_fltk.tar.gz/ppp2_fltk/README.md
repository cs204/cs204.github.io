# PPP2_FLTK
sudo apt install libfltk1.3-dev clang++-20 libc++-20-dev
