#include<ranges>
#include<iterator>
#include<iostream>
#include<vector>
#include<concepts>

using std::ranges::range_value_t;
using std::ranges::iterator_t;
using std::iter_value_t;
using std::input_iterator;
using std::same_as;

template<typename S>
concept Sequence = requires(S a){
	typename range_value_t<S>;
	typename iterator_t<S>;
	{a.begin()} -> same_as<iterator_t<S> >;
	{a.end()} -> same_as<iterator_t<S> >;
	requires input_iterator< iterator_t<S> >;
	requires same_as<range_value_t<S>, iter_value_t<S>>;
};

template<typename T, typename U = T>
concept Number = 
	requires(T x, U y){
		x + y;
		x - y;
		x * y;
		x / y;
		x += y;
		x -= y;
		x *= y; 
		x /= y;
		x = x;
		x = 0;
	};

template<typename T, typename U=T>
concept Arithmetic = Number<T,U> && Number<U, T>;


template<
	Sequence Seq, 
	Arithmetic< range_value_t<Seq> > Num
	>
Num sum(Seq s, Num v)
{
	for(const auto& x:s)
		v += x;
	return v;
}

int main()
{
	std::vector<int> v{1, 2, 3};
	std::cout  << "sum4 " << sum(v, 0) << std::endl;
}
