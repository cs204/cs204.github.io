#include<ranges>
#include<iostream>
#include<vector>

template<typename S>
concept Sequence = std::ranges::input_range<S>;

template<typename T, typename U = T>
concept Number = 
	requires(T x, U y){
		x + y;
		x - y;
		x * y;
		x / y;
		x += y;
		x -= y;
		x *= y; 
		x /= y;
		x = x;
		x = 0;
	};

template<typename T, typename U=T>
concept Arithmetic = Number<T,U> && Number<U, T>;


template<
	Sequence Seq, 
	Arithmetic< std::ranges::range_value_t<Seq> > Num
	>
Num sum(Seq s, Num v)
{
	for(const auto& x:s)
		v += x;
	return v;
}

int main()
{
	std::vector<int> v{1, 2, 3};
	std::cout  << "sum3 " << sum(v, 0) << std::endl;
}
