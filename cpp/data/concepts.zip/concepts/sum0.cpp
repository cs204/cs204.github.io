#include<iostream>
#include<vector>

template<typename Seq, typename Value>
Value sum(Seq s, Value v)
{
	for(const auto& x:s)
		v += x;
	return v;
}

int main()
{
	std::vector<int> v{1, 2, 3};
	std::cout  << sum(v, 0) << std::endl;
}
