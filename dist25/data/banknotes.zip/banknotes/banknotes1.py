
import csv
import random

from sklearn import svm
from sklearn.linear_model import Perceptron
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier

модель = Perceptron()
# модель = svm.SVC()
# модель = KNeighborsClassifier(n_neighbors=1)
# модель = GaussianNB()

# Читаем данные из файла
with open("banknotes.csv") as f:
    reader = csv.reader(f)
    next(reader)

    данные = []
    for строка in reader:
        данные.append({
            "признаки": [float(ячейка) for ячейка in строка[:4]],
            "метка": "Подлинная" if строка[4] == "0" else "Поддельная"
        })

# Разделите данные на группы обучения и тестирования
признаки = [строка["признаки"] for строка in данные]
метки = [строка["метка"] for строка in данные]
X_обучение, X_тестирование, y_обучение, y_тестирование = train_test_split(
    признаки, метки, test_size=0.4
)


# Обучить модель на тренировочном наборе
модель.fit(X_обучение, y_обучение)

# Делаем прогнозы на тестовом наборе
предсказания = модель.predict(X_тестирование)

# Подсчитайте, насколько хорошо мы справились

верных = (y_тестирование == предсказания).sum()
неверных = (y_тестирование != предсказания).sum()
всего = len(предсказания)

# Распечатать результаты
print(f"Результат для модели {type(модель).__name__}")
print(f"Верных: {верных}")
print(f"Неверных: {неверных}")
print(f"Правильность: {100 * верных / всего:.2f}%")
