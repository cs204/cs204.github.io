console.log("25 * 5 =", 25 * 5)
console.log("5 % 2 =", 5 % 2)
let x = 5
console.log("x < 6 =", x < 6)
console.log("x**5 = ", x**2)
console.log("sqrt(25)=", Math.sqrt(25))
console.log("корень кубический из 8 =", Math.pow(8,1/3))
console.log("sin(pi/2) = ", Math.sin(Math.PI /2))
let x = parseFloat("3.14")//преобразуем строку текста в число
console.log(typeof x) // typeof возвращает тип значения


