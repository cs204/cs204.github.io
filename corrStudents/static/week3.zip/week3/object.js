let person = {name: "Лена", age: 18}//Создали объект
console.log(person.name)
console.log(person["name"])
