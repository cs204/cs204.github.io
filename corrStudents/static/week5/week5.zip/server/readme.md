перейдите в папку server и выполните 
npm install
В файле pgConfig.js укажите URI вашей базды данных
