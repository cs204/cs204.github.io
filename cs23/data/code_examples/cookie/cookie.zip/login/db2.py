from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
from sqlalchemy.sql import text
url="sqlite:///test.db"
engine = create_engine(url)
db = scoped_session(sessionmaker(bind=engine))
db.execute(text("create table if not exists characters (id integer primary key autoincrement , username text not null unique, password text non tull)"))
row = db.execute(text("insert into characters (username, password) values (:username, :password)"), {"username": "potter", "password": "12345"})
db.commit()




