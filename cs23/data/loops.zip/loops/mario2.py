def main():
	print_square(3)

def print_square(size):
	#Для каждой строки в квадрате
	for i in range(size):
		# Для каждого кирпича в строке
		for j in range(size):
			print("#", end="")
		#Печатаем пустую строку
		print()

main()

