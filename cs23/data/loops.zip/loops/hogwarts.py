students = ["Гермиона", "Гарри", "Рон"]
print(students[0])
print(students[1])
print(students[2])

