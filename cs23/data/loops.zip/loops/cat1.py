print("мяу")
print("мяу")
print("мяу")

