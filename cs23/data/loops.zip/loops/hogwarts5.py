students={
	"Гермиона": "Гриффиндор",
	"Гарри": "Гриффиндор",
	"Рон": "Гриффиндор",
	"Драко": "Слизерин"
	}

for student in students:
	print(student, students[student], sep=", ")

