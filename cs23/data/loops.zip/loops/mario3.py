def main():
    print_square(3)


def print_square(n):
    for i in range(3):
        print_row(3)


def print_row(n):
    print("#"*n)

main()
