def main():
	print_row(4)

def print_row(width):
	print("?" * width)

main()

