for i in [0, 1, 2]:
	print(i, "мяу")

