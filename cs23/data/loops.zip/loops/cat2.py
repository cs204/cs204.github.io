i = 3
while i != 0:
	print("мяу")
	i = i - 1

