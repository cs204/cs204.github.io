while True: 
    n = int(input("Введите n: ")) 
    if n > 0: 
        break 
    else: 
        continue
 
for i in range(n): 
    print("мяу")

