students = ["Гермиона", "Гарри", "Рон"]
n = len(students)
for i in range(n):
	print(i, students[i])

