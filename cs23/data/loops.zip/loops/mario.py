def main():
	print_column(3)

def print_column(height):
	for i in range(height):
		print("#")

main()

