students = ["Гермиона", "Гарри", "Рон"]
for student in students:
	print(student)

