students={
	"Гермиона": "Гриффиндор",
	"Гарри": "Гриффиндор",
	"Рон": "Гриффиндор",
	"Драко": "Слизерин"
	}
print(students["Гермиона"])
print(students["Гарри"])
print(students["Рон"])
print(students["Драко"])

