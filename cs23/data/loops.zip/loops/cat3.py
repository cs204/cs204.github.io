i = 0
while i < 3:
	print("мяу")
	i += 1

