from flask import Flask, render_template, request
import json
from cs50 import SQL
db = SQL("sqlite:///hogwarts.db")

app = Flask(__name__)
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/search", methods=["POST"])
def search():
    response = json.loads(request.data)
    username = response["username"]
    if username:
        rows = db.execute("select * from characters where username like :username", username = username + "%")
    else:
        rows = []
    return json.dumps(rows)
