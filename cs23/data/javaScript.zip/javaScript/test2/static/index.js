let username = document.querySelector("#username")
let pOut = document.querySelector("#pOut")

async function search()
{
    let data = {"username": username.value}
    let response = await fetch("/search",
    {
        method: "POST",
        headers:
        {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
    let rows = await response.json()
    html = ''
    for (let row of rows)
    {
        html = html + row["username"] + "<br>"
    }
    pOut.innerHTML = html
}

username.addEventListener('input', search)
