let username = document.querySelector("#username")
let btnGreet = document.querySelector("#btnGreet")


function greet()
{
    alert("Привет, " + username.value + "!")
    document.querySelector("body").style.backgroundColor = "aqua";
}

btnGreet.addEventListener('click', greet)
