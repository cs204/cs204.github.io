def main():
    x = get_int("Введите x: ")
    print(f"x = {x}")

def get_int(prompt):
    while True:
        try:
            return int(input(prompt))
        except ValueError:
            pass

main()
