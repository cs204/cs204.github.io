while True:
    try:
        x = int(input("x: "))
    except ValueError:
        print("x не целое число")
    else:
        break

print(f"x = {x}")
