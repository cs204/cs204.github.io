def main():
    x = get_int()
    print(f"x = {x}")

def get_int():
    while True:
        try:
            return int(input("x: "))
        except ValueError:
            print("x не целое число")

main()
