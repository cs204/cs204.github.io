""" exceptions """
try: 
    x = int(input("Введите x: ")) 
except ValueError:
    print("x не целое число")
else:
    print(f"x = {x}")
