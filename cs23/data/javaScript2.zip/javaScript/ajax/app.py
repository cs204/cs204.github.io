from flask import Flask, render_template, redirect, request, session, jsonify
from flask_session import Session
from cs50 import SQL

app = Flask(__name__)

# Конфигурируем сессию
app.config["SESSION_PREMANENT"]  = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

db = SQL("sqlite:///hogwarts.db")

@app.route('/')
def index():
    if not session.get("username"):
        return redirect("/login")
    return render_template("index.html")

@app.route('/login', methods=["POST", "GET"])
def login():
    session.clear()
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        row = db.execute("select * from characters where username = :username", username = username)
        if len(row) == 0:
            return "No such username"
        if row[0]["password"] != password:
            return "Wrong password"
        session["username"] = username
        return redirect("/")
    return render_template("login.html")

@app.route('/register', methods=["POST", "GET"])
def register():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        row = db.execute("select * from characters where username = :username", username = username)
        if len(row):
            return "Such user allredy exists"
        db.execute("insert into characters (username, password) values (:username, :password)", username=username, password=password)
        session["username"] = username
        return redirect("/")
    else: 
        session.clear()
        return render_template("register.html")

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')


@app.route('/search')
def search():
    q = request.args.get("q")
    if q:
        users = db.execute("select username from characters where username like :q", q = "%" + q + "%")
    else:
        users = []
    return jsonify(users)

        



