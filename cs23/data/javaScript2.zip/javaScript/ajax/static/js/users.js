var usernameInput = document.querySelector('#usernameInput')
var usersP = document.querySelector('#users')

async function searchUsers()
{
	let response = await fetch('/search?q=' + usernameInput.value);
	let users = await(response.json())
	let html = ''
	console.log(users)
	for (let user of users)
	{
		html = html + user['username'] + '<br>';
	}
	usersP.innerHTML = html
}


usernameInput.addEventListener('input', searchUsers)
